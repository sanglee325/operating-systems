#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#include "bitmap.h"

void command_bitmap(char *command, char tokenize[MAX_INPUT_LEN][MAX_INPUT_LEN], int word_num);